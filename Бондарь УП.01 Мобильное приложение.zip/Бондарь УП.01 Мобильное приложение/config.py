import os


class Config:
    # Настройки базы данных
    DB_NAME = "sporticus"
    DB_USER = "postgres"
    DB_PASSWORD = "1234"  # Твой пароль от PostgreSQL
    DB_HOST = "localhost"
    DB_PORT = "5432"

    # Настройки приложения
    APP_NAME = "Спортикус Мобайл"
    APP_VERSION = "1.0.0"

    # Пути к файлам
    DATA_DIR = "data"
    LOGS_DIR = "logs"

    @classmethod
    def create_dirs(cls):
        """Создает необходимые директории"""
        os.makedirs(cls.DATA_DIR, exist_ok=True)
        os.makedirs(cls.LOGS_DIR, exist_ok=True)

    @classmethod
    def get_db_connection_string(cls):
        """Возвращает строку подключения к БД"""
        return f"dbname='{cls.DB_NAME}' user='{cls.DB_USER}' password='{cls.DB_PASSWORD}' host='{cls.DB_HOST}' port='{cls.DB_PORT}'"