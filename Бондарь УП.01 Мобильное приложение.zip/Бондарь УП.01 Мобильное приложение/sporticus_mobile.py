# sporticus_mobile.py (исправленная версия с правильной цветовой схемой)
"""
Мобильное приложение Спортикус с подключением к реальной БД
"""
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.image import Image
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout
from kivy.properties import StringProperty, ListProperty, BooleanProperty, NumericProperty, ObjectProperty
from kivy.clock import Clock
from kivy.uix.modalview import ModalView
from kivy.uix.dropdown import DropDown
from kivy.uix.spinner import Spinner
import platform

import database
from database import db
import json
import os
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Устанавливаем размер окна как у мобильного телефона
Window.size = (360, 640)
Window.clearcolor = (0.96, 0.96, 0.96, 1)  # Светло-серый фон

# Цветовая палитра для приложения (контрастная и читаемая)
COLORS = {
    'primary': (0.12, 0.47, 0.71, 1),  # Основной синий
    'primary_light': (0.2, 0.6, 0.9, 1),  # Светлый синий
    'secondary': (0.15, 0.68, 0.38, 1),  # Зеленый
    'accent': (0.91, 0.29, 0.21, 1),  # Красный акцент
    'warning': (1.0, 0.76, 0.03, 1),  # Желтый предупреждение
    'success': (0.18, 0.8, 0.44, 1),  # Зеленый успех
    'light': (1, 1, 1, 1),  # Белый
    'dark': (0.13, 0.13, 0.13, 1),  # Темный текст
    'gray': (0.74, 0.74, 0.74, 1),  # Серый
    'light_gray': (0.9, 0.9, 0.9, 1),  # Светло-серый
    'background': (0.96, 0.96, 0.96, 1),  # Фон
    'card': (1, 1, 1, 1),  # Карточки
}

# Определяем системные шрифты
if platform.system() == 'Windows':
    FONT_REGULAR = 'Arial'
    FONT_BOLD = 'Arial Bold'
    FONT_MEDIUM = 'Arial'
elif platform.system() == 'Linux':
    FONT_REGULAR = 'DejaVu Sans'
    FONT_BOLD = 'DejaVu Sans Bold'
    FONT_MEDIUM = 'DejaVu Sans'
else:  # macOS
    FONT_REGULAR = 'Helvetica'
    FONT_BOLD = 'Helvetica-Bold'
    FONT_MEDIUM = 'Helvetica'


class SporticusButton(Button):
    """Кастомная кнопка для приложения с правильной цветовой схемой"""

    def __init__(self, **kwargs):
        # Убираем стандартный цвет фона
        if 'background_color' not in kwargs:
            kwargs['background_color'] = (0, 0, 0, 0)
        if 'color' not in kwargs:
            kwargs['color'] = COLORS['light']  # Белый текст

        super().__init__(**kwargs)

        self.font_name = FONT_REGULAR
        self.font_size = '16sp'
        self.size_hint = (1, None)
        self.height = 50
        self.background_normal = ''
        self.background_down = ''
        self.bold = True

        # Рисуем красивый фон с тенью
        with self.canvas.before:
            # Тень
            Color(*COLORS['gray'], 0.3)
            self.shadow_rect = RoundedRectangle(
                pos=(self.pos[0] + 2, self.pos[1] - 2),
                size=self.size,
                radius=[8]
            )
            # Основной цвет
            Color(*COLORS['primary'])
            self.rect = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[8]
            )

        self.bind(pos=self.update_rect, size=self.update_rect)

    def update_rect(self, *args):
        if hasattr(self, 'rect'):
            self.rect.pos = self.pos
            self.rect.size = self.size
            self.shadow_rect.pos = (self.pos[0] + 2, self.pos[1] - 2)
            self.shadow_rect.size = self.size


class SporticusSecondaryButton(Button):
    """Вторичная кнопка (например, для отмены)"""

    def __init__(self, **kwargs):
        if 'background_color' not in kwargs:
            kwargs['background_color'] = (0, 0, 0, 0)
        if 'color' not in kwargs:
            kwargs['color'] = COLORS['dark']  # Темный текст

        super().__init__(**kwargs)

        self.font_name = FONT_REGULAR
        self.font_size = '16sp'
        self.size_hint = (1, None)
        self.height = 50
        self.background_normal = ''
        self.background_down = ''

        with self.canvas.before:
            # Тень
            Color(*COLORS['gray'], 0.2)
            self.shadow_rect = RoundedRectangle(
                pos=(self.pos[0] + 1, self.pos[1] - 1),
                size=self.size,
                radius=[8]
            )
            # Основной цвет
            Color(*COLORS['light_gray'])
            self.rect = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[8]
            )

        self.bind(pos=self.update_rect, size=self.update_rect)

    def update_rect(self, *args):
        if hasattr(self, 'rect'):
            self.rect.pos = self.pos
            self.rect.size = self.size
            self.shadow_rect.pos = (self.pos[0] + 1, self.pos[1] - 1)
            self.shadow_rect.size = self.size


class SporticusCard(BoxLayout):
    """Карточка для отображения информации с контрастным дизайном"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.size_hint = (1, None)
        self.height = 120
        self.padding = [15, 15]
        self.spacing = 8

        with self.canvas.before:
            # Тень
            Color(*COLORS['gray'], 0.1)
            self.shadow = RoundedRectangle(
                pos=(self.pos[0] + 2, self.pos[1] - 2),
                size=(self.size[0], self.size[1]),
                radius=[10]
            )
            # Фон карточки
            Color(*COLORS['card'])
            self.rect = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[10]
            )
            # Акцентная полоска сверху
            Color(*COLORS['primary'])
            self.accent = RoundedRectangle(
                pos=(self.pos[0], self.pos[1] + self.size[1] - 3),
                size=(self.size[0], 3),
                radius=[1]
            )

        self.bind(pos=self.update_graphics, size=self.update_graphics)

    def update_graphics(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size
        self.shadow.pos = (self.pos[0] + 2, self.pos[1] - 2)
        self.shadow.size = self.size
        self.accent.pos = (self.pos[0], self.pos[1] + self.size[1] - 3)
        self.accent.size = (self.size[0], 3)


class LoginScreen(Screen):
    """Экран входа в систему с подключением к БД"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'login'
        self.current_user = None

        # Основной контейнер
        main_layout = BoxLayout(
            orientation='vertical',
            padding=[30, 40, 30, 30],
            spacing=25
        )

        # Логотип и заголовок
        title_layout = BoxLayout(
            orientation='vertical',
            size_hint=(1, 0.35),
            spacing=10
        )

        # Логотип
        logo_container = BoxLayout(
            orientation='vertical',
            size_hint=(1, 0.6),
            padding=[0, 0, 0, 10]
        )

        with logo_container.canvas.before:
            Color(*COLORS['primary'])
            RoundedRectangle(
                pos=(
                    Window.width / 2 - 40,
                    Window.height - 180 if hasattr(Window, 'height') else 200
                ),
                size=(80, 80),
                radius=[20]
            )

        logo_label = Label(
            text='🏋️',
            font_size='48sp',
            size_hint=(1, 1),
            color=COLORS['light']
        )

        logo_container.add_widget(logo_label)

        # Заголовок
        title_label = Label(
            text='СПОРТИКУС',
            font_size='28sp',
            font_name=FONT_BOLD,
            color=COLORS['dark'],
            size_hint=(1, 0.2)
        )

        subtitle_label = Label(
            text='Мобильное приложение',
            font_size='16sp',
            color=COLORS['gray'],
            size_hint=(1, 0.2)
        )

        title_layout.add_widget(logo_container)
        title_layout.add_widget(title_label)
        title_layout.add_widget(subtitle_label)

        # Форма входа
        form_layout = BoxLayout(
            orientation='vertical',
            spacing=20,
            size_hint=(1, 0.65)
        )

        # Поле логина
        login_container = BoxLayout(orientation='vertical', spacing=8)
        login_label = Label(
            text='ЛОГИН',
            font_size='14sp',
            font_name=FONT_BOLD,
            color=COLORS['dark'],
            halign='left',
            size_hint=(1, None),
            height=25
        )

        self.login_input = TextInput(
            hint_text='Введите логин',
            size_hint=(1, None),
            height=55,
            multiline=False,
            padding=[20, 15],
            background_color=COLORS['light'],
            foreground_color=COLORS['dark'],
            hint_text_color=[0.7, 0.7, 0.7, 1],
            cursor_color=COLORS['primary'],
            background_normal='',
            background_active='',
            write_tab=False
        )

        # Стилизация поля ввода
        with self.login_input.canvas.before:
            Color(*COLORS['light_gray'])
            self.login_input.border = RoundedRectangle(
                pos=self.login_input.pos,
                size=self.login_input.size,
                radius=[8]
            )

        self.login_input.bind(pos=self.update_input_border, size=self.update_input_border)

        login_container.add_widget(login_label)
        login_container.add_widget(self.login_input)

        # Поле пароля
        pass_container = BoxLayout(orientation='vertical', spacing=8)
        pass_label = Label(
            text='ПАРОЛЬ',
            font_size='14sp',
            font_name=FONT_BOLD,
            color=COLORS['dark'],
            halign='left',
            size_hint=(1, None),
            height=25
        )

        self.pass_input = TextInput(
            hint_text='Введите пароль',
            size_hint=(1, None),
            height=55,
            multiline=False,
            password=True,
            padding=[20, 15],
            background_color=COLORS['light'],
            foreground_color=COLORS['dark'],
            hint_text_color=[0.7, 0.7, 0.7, 1],
            cursor_color=COLORS['primary'],
            background_normal='',
            background_active='',
            write_tab=False
        )

        with self.pass_input.canvas.before:
            Color(*COLORS['light_gray'])
            self.pass_input.border = RoundedRectangle(
                pos=self.pass_input.pos,
                size=self.pass_input.size,
                radius=[8]
            )

        self.pass_input.bind(pos=self.update_input_border, size=self.update_input_border)

        pass_container.add_widget(pass_label)
        pass_container.add_widget(self.pass_input)

        # Чекбокс "Запомнить меня"
        checkbox_layout = BoxLayout(
            orientation='horizontal',
            spacing=15,
            size_hint=(1, None),
            height=35
        )

        self.remember_check = CheckBox(
            size_hint=(None, None),
            size=(35, 35),
            color=COLORS['primary']
        )

        remember_label = Label(
            text='Запомнить меня',
            font_size='15sp',
            color=COLORS['dark']
        )

        checkbox_layout.add_widget(self.remember_check)
        checkbox_layout.add_widget(remember_label)
        checkbox_layout.add_widget(Widget())  # Spacer

        # Кнопка входа
        login_btn = SporticusButton(
            text='ВОЙТИ В СИСТЕМУ',
            color=COLORS['light']
        )
        login_btn.bind(on_press=self.login)

        # Ссылка "Забыли пароль?"
        forgot_link = Button(
            text='Забыли пароль?',
            font_size='14sp',
            color=COLORS['primary'],
            background_color=(0, 0, 0, 0),
            size_hint=(1, None),
            height=35,
            bold=False
        )
        forgot_link.bind(on_press=self.show_forgot_password)

        # Добавляем все в форму
        form_layout.add_widget(login_container)
        form_layout.add_widget(pass_container)
        form_layout.add_widget(checkbox_layout)
        form_layout.add_widget(login_btn)
        form_layout.add_widget(forgot_link)

        # Добавляем все в основной контейнер
        main_layout.add_widget(title_layout)
        main_layout.add_widget(form_layout)

        self.add_widget(main_layout)

    def update_input_border(self, instance, value):
        """Обновляет границы полей ввода"""
        if hasattr(instance, 'border'):
            instance.border.pos = instance.pos
            instance.border.size = instance.size

    def login(self, instance):
        """Обработка входа в систему с проверкой в БД"""
        login = self.login_input.text.strip()
        password = self.pass_input.text.strip()

        if not login or not password:
            self.show_error('Введите логин и пароль')
            return

        # Показываем индикатор загрузки
        self.show_loading("Проверка учетных данных...")

        # Запускаем аутентификацию в отдельном потоке через Clock
        Clock.schedule_once(lambda dt: self.authenticate(login, password), 0.1)

    def authenticate(self, login, password):
        """Аутентификация пользователя через БД"""
        try:
            # Подключаемся к БД
            if not db.connect():
                self.hide_loading()
                self.show_error("Ошибка подключения к базе данных")
                return

            # Проверяем учетные данные
            user = db.authenticate_user(login, password)

            if user:
                self.current_user = user
                logger.info(f"Пользователь {user['full_name']} успешно вошел в систему")

                # Сохраняем данные если нужно
                if self.remember_check.active:
                    # В реальном приложении нужно шифровать
                    pass

                # Переходим на главный экран
                self.hide_loading()
                self.manager.get_screen('main').set_user(user)
                self.manager.current = 'main'
            else:
                self.hide_loading()
                self.show_error('Неверный логин или пароль')

        except Exception as e:
            self.hide_loading()
            logger.error(f"Ошибка аутентификации: {e}")
            self.show_error(f'Ошибка сервера: {str(e)}')

    def show_loading(self, message="Загрузка..."):
        """Показывает модальное окно загрузки"""
        self.loading_popup = ModalView(
            size_hint=(0.7, 0.3),
            auto_dismiss=False,
            background_color=(0, 0, 0, 0.5)
        )

        content = BoxLayout(
            orientation='vertical',
            padding=25,
            spacing=20
        )

        with content.canvas.before:
            Color(*COLORS['light'])
            content.rect = RoundedRectangle(
                pos=content.pos,
                size=content.size,
                radius=[15]
            )

        content.bind(pos=self.update_popup_bg, size=self.update_popup_bg)

        loading_label = Label(
            text=message,
            font_size='17sp',
            color=COLORS['dark'],
            font_name=FONT_BOLD
        )

        spinner = Label(
            text='⏳',
            font_size='36sp'
        )

        content.add_widget(loading_label)
        content.add_widget(spinner)
        self.loading_popup.add_widget(content)
        self.loading_popup.open()

    def update_popup_bg(self, instance, value):
        if hasattr(instance, 'rect'):
            instance.rect.pos = instance.pos
            instance.rect.size = instance.size

    def hide_loading(self):
        """Скрывает модальное окно загрузки"""
        if hasattr(self, 'loading_popup'):
            self.loading_popup.dismiss()

    def show_forgot_password(self, instance):
        self.show_info(
            'Восстановление пароля',
            'Обратитесь к администратору системы для восстановления пароля.'
        )

    def show_error(self, message):
        """Показывает ошибку"""
        self.show_popup('Ошибка', message, 'error')

    def show_info(self, title, message):
        """Показывает информационное сообщение"""
        self.show_popup(title, message, 'info')

    def show_popup(self, title, message, popup_type='info'):
        """Универсальное модальное окно"""
        popup = ModalView(
            size_hint=(0.85, 0.4),
            background_color=(0, 0, 0, 0.5)
        )

        content = BoxLayout(
            orientation='vertical',
            padding=25,
            spacing=20
        )

        with content.canvas.before:
            Color(*COLORS['light'])
            content.rect = RoundedRectangle(
                pos=content.pos,
                size=content.size,
                radius=[15]
            )

        content.bind(pos=self.update_popup_bg, size=self.update_popup_bg)

        title_label = Label(
            text=title,
            font_size='22sp',
            font_name=FONT_BOLD,
            color=COLORS['dark'],
            size_hint=(1, 0.4)
        )

        msg_label = Label(
            text=message,
            font_size='16sp',
            color=COLORS['dark'],
            halign='center',
            valign='middle',
            size_hint=(1, 0.6)
        )
        msg_label.bind(size=msg_label.setter('text_size'))

        ok_btn = SporticusButton(
            text='ПОНЯТНО',
            color=COLORS['light']
        )

        if popup_type == 'error':
            with ok_btn.canvas.before:
                ok_btn.canvas.before.clear()
                Color(*COLORS['accent'])
                ok_btn.rect = RoundedRectangle(
                    pos=ok_btn.pos,
                    size=ok_btn.size,
                    radius=[8]
                )

        ok_btn.bind(on_press=lambda x: popup.dismiss())

        content.add_widget(title_label)
        content.add_widget(msg_label)
        content.add_widget(ok_btn)

        popup.add_widget(content)
        popup.open()


class MainScreen(Screen):
    """Главный экран приложения"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'main'
        self.current_user = None
        self.system_stats = {}

        # Основной контейнер с прокруткой
        scroll = ScrollView(
            bar_width=8,
            bar_color=COLORS['primary'],
            bar_inactive_color=COLORS['light_gray'],
            do_scroll_x=False
        )

        self.main_layout = BoxLayout(
            orientation='vertical',
            padding=[20, 20, 20, 30],
            spacing=25,
            size_hint_y=None
        )
        self.main_layout.bind(minimum_height=self.main_layout.setter('height'))

        scroll.add_widget(self.main_layout)
        self.add_widget(scroll)

    def on_enter(self):
        """Вызывается при входе на экран"""
        self.build_ui()
        self.load_system_stats()

    def set_user(self, user):
        """Устанавливает текущего пользователя"""
        self.current_user = user

    def build_ui(self):
        """Строит интерфейс главного экрана"""
        self.main_layout.clear_widgets()

        # Заголовок
        header = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=60,
            spacing=15
        )

        title_label = Label(
            text='ГЛАВНЫЙ ЭКРАН',
            font_size='24sp',
            font_name=FONT_BOLD,
            color=COLORS['dark'],
            halign='left',
            valign='middle'
        )
        title_label.bind(size=title_label.setter('text_size'))

        user_btn = Button(
            text='👤',
            font_size='26sp',
            size_hint=(None, None),
            size=(50, 50),
            background_color=(0, 0, 0, 0),
            color=COLORS['primary']
        )
        user_btn.bind(on_press=self.show_user_info)

        header.add_widget(title_label)
        header.add_widget(user_btn)

        # Приветственная карточка
        welcome_card = SporticusCard()
        welcome_card.height = 110

        welcome_content = BoxLayout(
            orientation='vertical',
            spacing=5
        )

        welcome_title = Label(
            text='ДОБРО ПОЖАЛОВАТЬ!',
            font_size='18sp',
            font_name=FONT_BOLD,
            color=COLORS['primary'],
            size_hint=(1, 0.4)
        )

        if self.current_user:
            welcome_name = Label(
                text=self.current_user['full_name'],
                font_size='20sp',
                font_name=FONT_BOLD,
                color=COLORS['dark'],
                size_hint=(1, 0.4)
            )
        else:
            welcome_name = Label(
                text='Гость',
                font_size='20sp',
                font_name=FONT_BOLD,
                color=COLORS['dark'],
                size_hint=(1, 0.4)
            )

        welcome_desc = Label(
            text='Система управления фитнес-клубом',
            font_size='14sp',
            color=COLORS['gray'],
            size_hint=(1, 0.2)
        )

        welcome_content.add_widget(welcome_title)
        welcome_content.add_widget(welcome_name)
        welcome_content.add_widget(welcome_desc)
        welcome_card.add_widget(welcome_content)

        # Быстрые действия (2 колонки)
        actions_title = Label(
            text='БЫСТРЫЕ ДЕЙСТВИЯ',
            font_size='16sp',
            font_name=FONT_BOLD,
            color=COLORS['dark'],
            size_hint=(1, None),
            height=30
        )

        actions_grid = GridLayout(
            cols=2,
            spacing=15,
            size_hint=(1, None),
            height=320
        )

        # Создаем кнопки действий
        actions = [
            ('👨‍🏫', 'ТРЕНЕРЫ', COLORS['primary'], self.go_to_trainers),
            ('👨‍💼', 'ПЕРСОНАЛ', COLORS['secondary'], self.go_to_staff),
            ('📅', 'РАСПИСАНИЕ', COLORS['warning'], self.show_schedule),
            ('📊', 'ОТЧЕТЫ', COLORS['accent'], self.show_reports),
            ('📈', 'СТАТИСТИКА', (0.58, 0.15, 0.71, 1), self.show_statistics),
            ('⚙️', 'НАСТРОЙКИ', (0.2, 0.2, 0.2, 1), self.show_settings)
        ]

        for icon, text, color, callback in actions:
            btn = self.create_action_button(icon, text, color)
            btn.bind(on_press=callback)
            actions_grid.add_widget(btn)

        # Статистика системы
        stats_card = SporticusCard()
        stats_card.height = 170

        stats_content = BoxLayout(
            orientation='vertical',
            spacing=8
        )

        stats_title = Label(
            text='📊 СТАТИСТИКА СИСТЕМЫ',
            font_size='16sp',
            font_name=FONT_BOLD,
            color=COLORS['dark'],
            size_hint=(1, 0.3)
        )

        stats_grid = GridLayout(
            cols=2,
            rows=3,
            spacing=10,
            size_hint=(1, None),
            height=100
        )

        self.trainers_count_label = Label(
            text='Тренеров: 0',
            font_size='14sp',
            color=COLORS['dark']
        )
        self.staff_count_label = Label(
            text='Персонала: 0',
            font_size='14sp',
            color=COLORS['dark']
        )
        self.users_count_label = Label(
            text='Пользователей: 0',
            font_size='14sp',
            color=COLORS['dark']
        )
        self.lessons_count_label = Label(
            text='Занятий: 0',
            font_size='14sp',
            color=COLORS['dark']
        )
        self.clients_count_label = Label(
            text='Клиентов: 0',
            font_size='14sp',
            color=COLORS['dark']
        )

        stats_grid.add_widget(self.trainers_count_label)
        stats_grid.add_widget(self.staff_count_label)
        stats_grid.add_widget(self.users_count_label)
        stats_grid.add_widget(self.lessons_count_label)
        stats_grid.add_widget(self.clients_count_label)
        stats_grid.add_widget(Widget())  # Пустая ячейка

        refresh_stats_btn = SporticusSecondaryButton(
            text='ОБНОВИТЬ СТАТИСТИКУ',
            color=COLORS['dark']
        )
        refresh_stats_btn.bind(on_press=lambda x: self.load_system_stats())

        stats_content.add_widget(stats_title)
        stats_content.add_widget(stats_grid)
        stats_content.add_widget(refresh_stats_btn)
        stats_card.add_widget(stats_content)

        # Кнопка выхода
        logout_btn = SporticusButton(
            text='ВЫЙТИ ИЗ СИСТЕМЫ',
            color=COLORS['light']
        )

        with logout_btn.canvas.before:
            logout_btn.canvas.before.clear()
            Color(*COLORS['accent'])
            logout_btn.rect = RoundedRectangle(
                pos=logout_btn.pos,
                size=logout_btn.size,
                radius=[8]
            )

        logout_btn.bind(on_press=self.logout)

        # Добавляем все элементы
        self.main_layout.add_widget(header)
        self.main_layout.add_widget(welcome_card)
        self.main_layout.add_widget(actions_title)
        self.main_layout.add_widget(actions_grid)
        self.main_layout.add_widget(stats_card)
        self.main_layout.add_widget(logout_btn)

    def go_to_trainers(self, instance):
        """Переход к экрану тренеров"""
        self.manager.current = 'trainers'

    def go_to_staff(self, instance):
        """Переход к экрану персонала"""
        self.manager.current = 'staff'

    def create_action_button(self, icon, text, color):
        """Создает кнопку быстрого действия"""
        btn = Button(
            size_hint=(1, None),
            height=100,
            background_color=(0, 0, 0, 0)
        )

        with btn.canvas.before:
            # Тень
            Color(*[c * 0.7 for c in color[:3]] + [0.3])
            btn.shadow = RoundedRectangle(
                pos=(btn.pos[0] + 3, btn.pos[1] - 3),
                size=btn.size,
                radius=[12]
            )
            # Основной цвет
            Color(*color)
            btn.rect = RoundedRectangle(
                pos=btn.pos,
                size=btn.size,
                radius=[12]
            )

        btn.bind(pos=self.update_action_btn, size=self.update_action_btn)

        content = BoxLayout(
            orientation='vertical',
            padding=10,
            spacing=5
        )

        icon_label = Label(
            text=icon,
            font_size='32sp'
        )

        text_label = Label(
            text=text,
            font_size='15sp',
            font_name=FONT_BOLD,
            color=COLORS['light'],
            halign='center'
        )
        text_label.bind(size=text_label.setter('text_size'))

        content.add_widget(icon_label)
        content.add_widget(text_label)
        btn.add_widget(content)

        return btn

    def update_action_btn(self, instance, value):
        if hasattr(instance, 'rect'):
            instance.rect.pos = instance.pos
            instance.rect.size = instance.size
            instance.shadow.pos = (instance.pos[0] + 3, instance.pos[1] - 3)
            instance.shadow.size = instance.size

    def load_system_stats(self):
        """Загружает статистику системы из БД"""
        try:
            stats = db.get_system_stats()
            self.system_stats = stats

            # Обновляем UI
            self.trainers_count_label.text = f'Тренеров: {stats["trainer_count"]}'
            self.staff_count_label.text = f'Персонала: {stats["staff_count"]}'
            self.users_count_label.text = f'Пользователей: {stats["user_count"]}'
            self.lessons_count_label.text = f'Занятий: {stats["estimated_lessons"]}'
            self.clients_count_label.text = f'Клиентов: {stats["estimated_clients"]}'

        except Exception as e:
            logger.error(f"Ошибка загрузки статистики: {e}")

    def show_user_info(self, instance):
        if self.current_user:
            message = f"Имя: {self.current_user['full_name']}\n\nЛогин: {self.current_user['login']}"
        else:
            message = "Гость"
        self.show_info('ИНФОРМАЦИЯ О ПОЛЬЗОВАТЕЛЕ', message)

    def show_schedule(self, instance):
        self.show_info('РАСПИСАНИЕ', 'Просмотр расписания доступен в разделе "Тренеры"')

    def show_reports(self, instance):
        self.show_info('ОТЧЕТЫ', 'Генерация отчетов будет доступна в следующем обновлении')

    def show_statistics(self, instance):
        stats_text = f"""
        СТАТИСТИКА СИСТЕМЫ:

        👨‍🏫 Тренеров: {self.system_stats.get('trainer_count', 0)}
        👨‍💼 Персонала: {self.system_stats.get('staff_count', 0)}
        👥 Пользователей: {self.system_stats.get('user_count', 0)}
        📅 Занятий в неделю: {self.system_stats.get('estimated_lessons', 0)}
        🏃 Клиентов в неделю: {self.system_stats.get('estimated_clients', 0)}
        """
        self.show_info('СТАТИСТИКА СИСТЕМЫ', stats_text)

    def show_settings(self, instance):
        self.show_info('НАСТРОЙКИ', 'Настройки приложения будут доступны в следующем обновлении')

    def logout(self, instance):
        db.disconnect()
        self.manager.current = 'login'

    def show_info(self, title, message):
        popup = ModalView(
            size_hint=(0.85, 0.5),
            background_color=(0, 0, 0, 0.5)
        )

        content = BoxLayout(
            orientation='vertical',
            padding=25,
            spacing=20
        )

        with content.canvas.before:
            Color(*COLORS['light'])
            content.rect = RoundedRectangle(
                pos=content.pos,
                size=content.size,
                radius=[15]
            )

        content.bind(pos=self.update_popup_bg, size=self.update_popup_bg)

        title_label = Label(
            text=title,
            font_size='22sp',
            font_name=FONT_BOLD,
            color=COLORS['dark']
        )

        msg_label = Label(
            text=message,
            font_size='16sp',
            color=COLORS['dark'],
            halign='center',
            valign='middle'
        )
        msg_label.bind(size=msg_label.setter('text_size'))

        ok_btn = SporticusButton(
            text='ПОНЯТНО',
            color=COLORS['light']
        )
        ok_btn.bind(on_press=lambda x: popup.dismiss())

        content.add_widget(title_label)
        content.add_widget(msg_label)
        content.add_widget(ok_btn)

        popup.add_widget(content)
        popup.open()

    def update_popup_bg(self, instance, value):
        if hasattr(instance, 'rect'):
            instance.rect.pos = instance.pos
            instance.rect.size = instance.size


# Остальной код остается без изменений (TrainersScreen, StaffScreen и SporticusMobileApp)
# Классы TrainersScreen и StaffScreen нужно аналогично обновить с использованием новой цветовой палитры
# В целях экономии места, я покажу только исправление классов Card в этих экранах:

class TrainersScreen(Screen):
    """Экран со списком тренеров из БД"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'trainers'

        # Основной контейнер
        main_layout = BoxLayout(orientation='vertical')

        # Шапка
        header = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=60,
            padding=[20, 0]
        )

        back_btn = Button(
            text='←',
            font_size='28sp',
            size_hint=(None, None),
            size=(50, 50),
            background_color=(0, 0, 0, 0),
            color=COLORS['primary']
        )
        back_btn.bind(on_press=self.go_back)

        title_label = Label(
            text='ТРЕНЕРЫ',
            font_size='24sp',
            font_name=FONT_BOLD,
            color=COLORS['dark']
        )

        refresh_btn = Button(
            text='🔄',
            font_size='24sp',
            size_hint=(None, None),
            size=(50, 50),
            background_color=(0, 0, 0, 0),
            color=COLORS['primary']
        )
        refresh_btn.bind(on_press=self.refresh_trainers)

        header.add_widget(back_btn)
        header.add_widget(title_label)
        header.add_widget(refresh_btn)

        # Поле поиска
        search_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=55,
            padding=[20, 10, 20, 5],
            spacing=10
        )

        self.search_input = TextInput(
            hint_text='Поиск тренера...',
            size_hint=(0.8, 1),
            multiline=False,
            padding=[15, 10],
            background_color=COLORS['light'],
            foreground_color=COLORS['dark'],
            hint_text_color=[0.7, 0.7, 0.7, 1],
            cursor_color=COLORS['primary']
        )

        search_btn = SporticusButton(
            text='🔍',
            color=COLORS['light']
        )
        search_btn.size_hint = (0.2, 1)
        search_btn.height = 55
        search_btn.bind(on_press=self.search_trainers)

        search_layout.add_widget(self.search_input)
        search_layout.add_widget(search_btn)

        # Список тренеров с прокруткой
        scroll = ScrollView(
            bar_width=8,
            bar_color=COLORS['primary'],
            bar_inactive_color=COLORS['light_gray']
        )

        self.trainers_list = BoxLayout(
            orientation='vertical',
            spacing=15,
            padding=[20, 10, 20, 20],
            size_hint_y=None
        )
        self.trainers_list.bind(minimum_height=self.trainers_list.setter('height'))

        scroll.add_widget(self.trainers_list)

        # Кнопка добавления
        add_btn = SporticusButton(
            text='+ ДОБАВИТЬ ТРЕНЕРА',
            color=COLORS['light']
        )
        add_btn.bind(on_press=self.show_add_trainer_form)

        # Добавляем все элементы
        main_layout.add_widget(header)
        main_layout.add_widget(search_layout)
        main_layout.add_widget(scroll)
        main_layout.add_widget(add_btn)

        self.add_widget(main_layout)

    # ... остальные методы без изменений ...

    def create_trainer_card(self, trainer):
        """Создает карточку тренера из данных БД"""
        card = SporticusCard()
        card.height = 130  # Немного увеличим высоту для лучшей читаемости

        content = BoxLayout(orientation='vertical', spacing=5)

        # Верхняя строка: имя и кнопка меню
        top_row = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=30
        )

        name_label = Label(
            text=trainer['full_name'],
            font_size='18sp',
            font_name=FONT_BOLD,
            halign='left',
            color=COLORS['dark']
        )
        name_label.bind(size=name_label.setter('text_size'))

        menu_btn = Button(
            text='⋯',
            font_size='24sp',
            size_hint=(None, None),
            size=(40, 40),
            background_color=(0, 0, 0, 0),
            color=COLORS['primary']
        )
        menu_btn.bind(on_press=lambda x, t=trainer: self.show_trainer_menu(t))

        top_row.add_widget(name_label)
        top_row.add_widget(menu_btn)

        # Направление тренировок
        sport_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=25,
            spacing=10
        )

        sport_icon = Label(
            text='🏋️‍♂️',
            font_size='16sp'
        )

        sport_label = Label(
            text=trainer['direction'],
            font_size='16sp',
            color=COLORS['primary'],
            font_name=FONT_BOLD
        )

        sport_layout.add_widget(sport_icon)
        sport_layout.add_widget(sport_label)
        sport_layout.add_widget(Widget())  # Spacer

        # Дни работы
        days_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=25,
            spacing=10
        )

        days_icon = Label(
            text='📅',
            font_size='16sp'
        )

        days_text = trainer['work_days'].replace(',', ', ')
        days_label = Label(
            text=f'Дни: {days_text}',
            font_size='14sp',
            color=COLORS['dark']
        )

        days_layout.add_widget(days_icon)
        days_layout.add_widget(days_label)
        days_layout.add_widget(Widget())  # Spacer

        # Статистика
        stats_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=35,
            spacing=20
        )

        lessons_stat = BoxLayout(orientation='vertical', spacing=2)
        lessons_value = Label(
            text=str(trainer['estimated_lessons']),
            font_size='20sp',
            font_name=FONT_BOLD,
            color=COLORS['primary']
        )
        lessons_label = Label(
            text='занятий/нед',
            font_size='12sp',
            color=COLORS['gray']
        )
        lessons_stat.add_widget(lessons_value)
        lessons_stat.add_widget(lessons_label)

        clients_stat = BoxLayout(orientation='vertical', spacing=2)
        clients_value = Label(
            text=str(trainer['estimated_clients']),
            font_size='20sp',
            font_name=FONT_BOLD,
            color=COLORS['secondary']
        )
        clients_label = Label(
            text='клиентов/нед',
            font_size='12sp',
            color=COLORS['gray']
        )
        clients_stat.add_widget(clients_value)
        clients_stat.add_widget(clients_label)

        stats_layout.add_widget(lessons_stat)
        stats_layout.add_widget(clients_stat)
        stats_layout.add_widget(Widget())  # Spacer

        # Собираем всё вместе
        content.add_widget(top_row)
        content.add_widget(sport_layout)
        content.add_widget(days_layout)
        content.add_widget(stats_layout)

        card.add_widget(content)
        return card

    # ... остальные методы без изменений ...


class StaffScreen(Screen):
    """Экран со списком персонала из БД"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'staff'

        # Основной контейнер
        main_layout = BoxLayout(orientation='vertical')

        # Шапка
        header = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=60,
            padding=[20, 0]
        )

        back_btn = Button(
            text='←',
            font_size='28sp',
            size_hint=(None, None),
            size=(50, 50),
            background_color=(0, 0, 0, 0),
            color=COLORS['primary']
        )
        back_btn.bind(on_press=self.go_back)

        title_label = Label(
            text='ПЕРСОНАЛ',
            font_size='24sp',
            font_name=FONT_BOLD,
            color=COLORS['dark']
        )

        refresh_btn = Button(
            text='🔄',
            font_size='24sp',
            size_hint=(None, None),
            size=(50, 50),
            background_color=(0, 0, 0, 0),
            color=COLORS['primary']
        )
        refresh_btn.bind(on_press=self.refresh_staff)

        header.add_widget(back_btn)
        header.add_widget(title_label)
        header.add_widget(refresh_btn)

        # Подзаголовок
        subtitle = Label(
            text='Административный персонал\nУправление сотрудниками',
            font_size='14sp',
            color=COLORS['gray'],
            halign='center',
            size_hint=(1, None),
            height=50
        )

        # Список персонала с прокруткой
        scroll = ScrollView(
            bar_width=8,
            bar_color=COLORS['primary'],
            bar_inactive_color=COLORS['light_gray']
        )

        self.staff_list = BoxLayout(
            orientation='vertical',
            spacing=15,
            padding=[20, 10, 20, 20],
            size_hint_y=None
        )
        self.staff_list.bind(minimum_height=self.staff_list.setter('height'))

        scroll.add_widget(self.staff_list)

        # Кнопка добавления
        add_btn = SporticusButton(
            text='+ ДОБАВИТЬ СОТРУДНИКА',
            color=COLORS['light']
        )
        add_btn.bind(on_press=self.show_add_staff_form)

        # Добавляем все элементы
        main_layout.add_widget(header)
        main_layout.add_widget(subtitle)
        main_layout.add_widget(scroll)
        main_layout.add_widget(add_btn)

        self.add_widget(main_layout)

    # ... остальные методы без изменений ...

    def create_staff_card(self, staff):
        """Создает карточку сотрудника из данных БД"""
        card = SporticusCard()
        card.height = 130

        content = BoxLayout(orientation='vertical', spacing=5)

        # Верхняя строка: имя
        name_label = Label(
            text=staff['full_name'],
            font_size='18sp',
            font_name=FONT_BOLD,
            halign='left',
            color=COLORS['dark']
        )
        name_label.bind(size=name_label.setter('text_size'))

        # Должность
        position_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=25,
            spacing=10
        )

        position_icon = Label(
            text='💼',
            font_size='16sp'
        )

        position_label = Label(
            text=staff['position'],
            font_size='16sp',
            color=COLORS['primary'],
            font_name=FONT_BOLD
        )

        position_layout.add_widget(position_icon)
        position_layout.add_widget(position_label)
        position_layout.add_widget(Widget())  # Spacer

        # График работы
        schedule_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, None),
            height=50,
            spacing=10
        )

        schedule_icon = Label(
            text='🕐',
            font_size='16sp'
        )

        schedule_label = Label(
            text=staff['schedule'],
            font_size='14sp',
            color=COLORS['dark'],
            halign='left',
            valign='top'
        )
        schedule_label.bind(size=schedule_label.setter('text_size'))

        # Кнопка карты доступа
        card_btn = Button(
            text='🪪',
            font_size='22sp',
            size_hint=(None, None),
            size=(50, 50),
            background_color=(0, 0, 0, 0),
            color=COLORS['primary']
        )
        card_btn.bind(on_press=lambda x, s=staff: self.generate_card(s))

        schedule_layout.add_widget(schedule_icon)
        schedule_layout.add_widget(schedule_label)
        schedule_layout.add_widget(card_btn)

        # Собираем всё вместе
        content.add_widget(name_label)
        content.add_widget(position_layout)
        content.add_widget(schedule_layout)

        card.add_widget(content)
        return card

    # ... остальные методы без изменений ...


class SporticusMobileApp(App):
    """Главное приложение"""

    def build(self):
        self.title = 'Спортикус Мобайл'
        self.icon = ''  # Можно добавить иконку приложения

        # Менеджер экранов
        sm = ScreenManager(transition=SlideTransition(duration=0.3))

        # Добавляем экраны
        sm.add_widget(LoginScreen())
        sm.add_widget(MainScreen())
        sm.add_widget(TrainersScreen())
        sm.add_widget(StaffScreen())

        return sm

    def on_stop(self):
        """Закрываем соединение с БД при выходе"""
        db.disconnect()


if __name__ == '__main__':
    SporticusMobileApp().run()