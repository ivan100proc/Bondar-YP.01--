import psycopg2
from psycopg2.extras import RealDictCursor
import hashlib
import logging
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)


class SporticusDatabase:
    def __init__(self):
        self.connection = None

    def connect(self):
        """Подключение к базе данных"""
        try:
            self.connection = psycopg2.connect(
                dbname="sporticus",
                user="postgres",
                password="1234",
                host="localhost",
                port="5432",
                cursor_factory=RealDictCursor
            )
            logger.info("✅ Подключение к базе данных успешно")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка подключения к БД: {e}")
            return False

    def disconnect(self):
        """Отключение от базы данных"""
        if self.connection:
            self.connection.close()
            self.connection = None

    def authenticate_user(self, login: str, password: str) -> Optional[Dict]:
        """Аутентификация пользователя"""
        try:
            with self.connection.cursor() as cursor:
                # В реальной системе пароли должны быть захешированы
                # Для демо сравниваем как есть
                query = """
                    SELECT user_id, login, full_name 
                    FROM users 
                    WHERE login = %s AND password_hash = %s
                """
                cursor.execute(query, (login, password))
                user = cursor.fetchone()
                return dict(user) if user else None
        except Exception as e:
            logger.error(f"Ошибка аутентификации: {e}")
            return None

    def get_all_trainers(self) -> List[Dict]:
        """Получение всех тренеров с расширенной статистикой"""
        try:
            with self.connection.cursor() as cursor:
                query = """
                    SELECT 
                        u.full_name,
                        wt.workout_type_name as direction,
                        STRING_AGG(ts.day_of_week, ',' ORDER BY 
                            CASE ts.day_of_week
                                WHEN 'Пн' THEN 1 WHEN 'Вт' THEN 2 WHEN 'Ср' THEN 3
                                WHEN 'Чт' THEN 4 WHEN 'Пт' THEN 5 WHEN 'Сб' THEN 6
                                WHEN 'Вс' THEN 7
                            END) as work_days,
                        COUNT(DISTINCT ts.day_of_week) as days_count,
                        (COUNT(DISTINCT ts.day_of_week) * 4) as estimated_lessons,
                        (COUNT(DISTINCT ts.day_of_week) * 4 * 10) as estimated_clients
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    JOIN workout_types wt ON t.workout_type_id = wt.workout_type_id
                    JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                    GROUP BY u.full_name, wt.workout_type_name
                    ORDER BY u.full_name
                """
                cursor.execute(query)
                trainers = cursor.fetchall()
                return [dict(trainer) for trainer in trainers]
        except Exception as e:
            logger.error(f"Ошибка получения тренеров: {e}")
            return []

    def get_all_staff(self) -> List[Dict]:
        """Получение всего персонала"""
        try:
            with self.connection.cursor() as cursor:
                query = """
                    SELECT 
                        s.staff_id,
                        u.full_name,
                        p.position_name as position,
                        s.work_schedule as schedule
                    FROM staff s
                    JOIN users u ON s.user_id = u.user_id
                    JOIN positions p ON s.position_id = p.position_id
                    ORDER BY u.full_name
                """
                cursor.execute(query)
                staff = cursor.fetchall()
                return [dict(employee) for employee in staff]
        except Exception as e:
            logger.error(f"Ошибка получения персонала: {e}")
            return []

    def search_trainers(self, search_text: str) -> List[Dict]:
        """Поиск тренеров по имени или направлению"""
        try:
            with self.connection.cursor() as cursor:
                query = """
                    SELECT 
                        u.full_name,
                        wt.workout_type_name as direction,
                        STRING_AGG(ts.day_of_week, ',' ORDER BY 
                            CASE ts.day_of_week
                                WHEN 'Пн' THEN 1 WHEN 'Вт' THEN 2 WHEN 'Ср' THEN 3
                                WHEN 'Чт' THEN 4 WHEN 'Пт' THEN 5 WHEN 'Сб' THEN 6
                                WHEN 'Вс' THEN 7
                            END) as work_days,
                        COUNT(DISTINCT ts.day_of_week) as days_count,
                        (COUNT(DISTINCT ts.day_of_week) * 4) as estimated_lessons,
                        (COUNT(DISTINCT ts.day_of_week) * 4 * 10) as estimated_clients
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    JOIN workout_types wt ON t.workout_type_id = wt.workout_type_id
                    JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                    WHERE LOWER(u.full_name) LIKE LOWER(%s) 
                       OR LOWER(wt.workout_type_name) LIKE LOWER(%s)
                    GROUP BY u.full_name, wt.workout_type_name
                    ORDER BY u.full_name
                """
                search_pattern = f"%{search_text}%"
                cursor.execute(query, (search_pattern, search_pattern))
                trainers = cursor.fetchall()
                return [dict(trainer) for trainer in trainers]
        except Exception as e:
            logger.error(f"Ошибка поиска тренеров: {e}")
            return []

    def add_trainer(self, user_id: int, workout_type_id: int, work_days: list) -> bool:
        """Добавление нового тренера"""
        try:
            with self.connection.cursor() as cursor:
                # Добавляем тренера
                cursor.execute("""
                    INSERT INTO trainers (user_id, workout_type_id) 
                    VALUES (%s, %s) RETURNING trainer_id
                """, (user_id, workout_type_id))

                trainer_id = cursor.fetchone()['trainer_id']

                # Добавляем дни работы
                for day in work_days:
                    cursor.execute("""
                        INSERT INTO trainer_schedules (trainer_id, day_of_week)
                        VALUES (%s, %s)
                    """, (trainer_id, day))

                self.connection.commit()
                return True
        except Exception as e:
            logger.error(f"Ошибка добавления тренера: {e}")
            self.connection.rollback()
            return False

    def delete_trainer(self, trainer_name: str) -> bool:
        """Удаление тренера по имени"""
        try:
            with self.connection.cursor() as cursor:
                # Находим ID тренера
                cursor.execute("""
                    SELECT t.trainer_id 
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    WHERE u.full_name = %s
                """, (trainer_name,))

                result = cursor.fetchone()
                if not result:
                    return False

                trainer_id = result['trainer_id']

                # Удаляем расписание
                cursor.execute("DELETE FROM trainer_schedules WHERE trainer_id = %s",
                               (trainer_id,))
                # Удаляем тренера
                cursor.execute("DELETE FROM trainers WHERE trainer_id = %s",
                               (trainer_id,))

                self.connection.commit()
                return True
        except Exception as e:
            logger.error(f"Ошибка удаления тренера: {e}")
            self.connection.rollback()
            return False

    def add_staff(self, user_id: int, position_id: int, schedule: str) -> bool:
        """Добавление нового сотрудника"""
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO staff (user_id, position_id, work_schedule) 
                    VALUES (%s, %s, %s) RETURNING staff_id
                """, (user_id, position_id, schedule))

                self.connection.commit()
                return True
        except Exception as e:
            logger.error(f"Ошибка добавления сотрудника: {e}")
            self.connection.rollback()
            return False

    def get_available_users(self) -> List[Dict]:
        """Получение пользователей, которые еще не являются тренерами или сотрудниками"""
        try:
            with self.connection.cursor() as cursor:
                query = """
                    SELECT u.user_id, u.full_name, u.login
                    FROM users u
                    WHERE u.user_id NOT IN (
                        SELECT user_id FROM trainers
                        UNION
                        SELECT user_id FROM staff
                    )
                    ORDER BY u.full_name
                """
                cursor.execute(query)
                users = cursor.fetchall()
                return [dict(user) for user in users]
        except Exception as e:
            logger.error(f"Ошибка получения пользователей: {e}")
            return []

    def get_workout_types(self) -> List[Dict]:
        """Получение всех типов тренировок"""
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "SELECT workout_type_id, workout_type_name FROM workout_types ORDER BY workout_type_name")
                types = cursor.fetchall()
                return [dict(t) for t in types]
        except Exception as e:
            logger.error(f"Ошибка получения типов тренировок: {e}")
            return []

    def get_positions(self) -> List[Dict]:
        """Получение всех должностей"""
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT position_id, position_name FROM positions ORDER BY position_name")
                positions = cursor.fetchall()
                return [dict(p) for p in positions]
        except Exception as e:
            logger.error(f"Ошибка получения должностей: {e}")
            return []

    def get_system_stats(self) -> Dict:
        """Получение статистики системы"""
        try:
            with self.connection.cursor() as cursor:
                # Статистика по тренерам
                cursor.execute("""
                    SELECT 
                        COUNT(DISTINCT t.trainer_id) as trainer_count,
                        COUNT(DISTINCT ts.schedule_id) as total_sessions,
                        SUM(
                            (SELECT COUNT(DISTINCT day_of_week) 
                             FROM trainer_schedules ts2 
                             WHERE ts2.trainer_id = t.trainer_id) * 4
                        ) as estimated_lessons,
                        SUM(
                            (SELECT COUNT(DISTINCT day_of_week) 
                             FROM trainer_schedules ts2 
                             WHERE ts2.trainer_id = t.trainer_id) * 4 * 10
                        ) as estimated_clients
                    FROM trainers t
                    LEFT JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                """)
                trainer_stats = cursor.fetchone()

                # Статистика по персоналу
                cursor.execute("SELECT COUNT(*) as staff_count FROM staff")
                staff_stats = cursor.fetchone()

                # Статистика по пользователям
                cursor.execute("SELECT COUNT(*) as user_count FROM users")
                user_stats = cursor.fetchone()

                return {
                    'trainer_count': trainer_stats['trainer_count'] or 0,
                    'staff_count': staff_stats['staff_count'] or 0,
                    'user_count': user_stats['user_count'] or 0,
                    'estimated_lessons': trainer_stats['estimated_lessons'] or 0,
                    'estimated_clients': trainer_stats['estimated_clients'] or 0
                }
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {
                'trainer_count': 0,
                'staff_count': 0,
                'user_count': 0,
                'estimated_lessons': 0,
                'estimated_clients': 0
            }


# Синглтон для доступа к БД
db = SporticusDatabase()