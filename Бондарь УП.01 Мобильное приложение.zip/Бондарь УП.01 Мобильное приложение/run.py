import subprocess
import sys
import os


def check_dependencies():
    """Проверяет наличие зависимостей"""
    dependencies = {
        'kivy': 'Kivy',
        'psycopg2': 'psycopg2-binary',
        'PIL': 'Pillow'
    }

    missing = []

    for module, package in dependencies.items():
        try:
            __import__(module if module != 'PIL' else 'PIL.Image')
            print(f"✅ {package} установлен")
        except ImportError:
            print(f"❌ {package} не установлен")
            missing.append(package)

    return len(missing) == 0


def check_database():
    """Проверяет доступность базы данных"""
    try:
        import database
        db = database.SporticusDatabase()

        if db.connect():
            print("✅ Подключение к базе данных успешно")

            # Проверяем наличие таблиц
            with db.connection.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM users")
                user_count = cursor.fetchone()['count']
                print(f"📊 Пользователей в системе: {user_count}")

                cursor.execute("SELECT COUNT(*) FROM trainers")
                trainer_count = cursor.fetchone()['count']
                print(f"👨‍🏫 Тренеров в системе: {trainer_count}")

                cursor.execute("SELECT COUNT(*) FROM staff")
                staff_count = cursor.fetchone()['count']
                print(f"👨‍💼 Сотрудников в системе: {staff_count}")

            db.disconnect()
            return True
        else:
            print("❌ Не удалось подключиться к базе данных")
            print("\nУбедитесь, что:")
            print("1. PostgreSQL запущен")
            print("2. База данных 'sporticus' существует")
            print("3. Пароль пользователя 'postgres' указан верно")
            return False

    except Exception as e:
        print(f"❌ Ошибка проверки БД: {e}")
        return False


def install_dependencies():
    """Устанавливает недостающие зависимости"""
    print("\nУстановка зависимостей...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])


def print_welcome():
    """Выводит приветственное сообщение"""
    print("=" * 50)
    print("🚀 СПОРТИКУС МОБАЙЛ")
    print("Мобильное приложение для управления фитнес-клубом")
    print("=" * 50)
    print("\n📱 Характеристики:")
    print("• Подключение к PostgreSQL базе данных")
    print("• Реальная аутентификация пользователей")
    print("• Управление тренерами и персоналом")
    print("• Material Design интерфейс")
    print("• Размер окна: 360x640 (мобильный)")

    print("\n🔑 Тестовые учетные данные из БД:")
    print("• Используйте логин и пароль из таблицы users")

    print("\n🛠 Технические требования:")
    print("• Python 3.7+")
    print("• PostgreSQL 12+")
    print("• База данных 'sporticus' (из твоего дампа)")


def run_app():
    """Запускает приложение"""
    print("\n" + "=" * 50)
    print("🚀 Запуск приложения...")

    from sporticus_mobile import SporticusMobileApp
    SporticusMobileApp().run()


if __name__ == '__main__':
    print_welcome()

    # Проверяем зависимости
    if not check_dependencies():
        print("\n❌ Отсутствуют необходимые зависимости!")
        response = input("Установить автоматически? (y/n): ")
        if response.lower() == 'y':
            install_dependencies()
        else:
            print("Установите вручную: pip install -r requirements.txt")
            sys.exit(1)

    # Проверяем базу данных
    if not check_database():
        print("\n❌ Проблемы с базой данных!")
        print("\nИнструкция по настройке PostgreSQL:")
        print("1. Установите PostgreSQL: https://www.postgresql.org/download/")
        print("2. Создайте базу данных: createdb sporticus")
        print("3. Импортируй дамп: psql sporticus < sporticus.sql")
        print("4. Проверь пароль пользователя postgres")

        response = input("\nПродолжить без проверки БД? (y/n): ")
        if response.lower() != 'y':
            sys.exit(1)

    # Запускаем приложение
    try:
        run_app()
    except KeyboardInterrupt:
        print("\n\n👋 Приложение завершено")
    except Exception as e:
        print(f"\n❌ Ошибка запуска: {e}")
        import traceback

        traceback.print_exc()