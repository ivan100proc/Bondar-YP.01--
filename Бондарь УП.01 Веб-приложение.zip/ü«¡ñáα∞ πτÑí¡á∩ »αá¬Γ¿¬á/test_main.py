# test_main.py
import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime
import io
import tempfile
import os

from main import app
import database


# Фикстура для тестового клиента
@pytest.fixture
def client():
    return TestClient(app)


# Фикстура для мока соединения с БД
@pytest.fixture
def mock_db_connection():
    with patch('database.get_db_connection') as mock_conn:
        # Создаем мок для курсора
        mock_cursor = MagicMock()
        mock_conn.return_value.cursor.return_value.__enter__.return_value = mock_cursor

        # Мокаем fetchone и fetchall
        mock_cursor.fetchone.return_value = None
        mock_cursor.fetchall.return_value = []

        yield mock_conn


# Тесты для страниц HTML
class TestPageRendering:

    def test_root_page(self, client):
        """Тест главной страницы"""
        response = client.get("/")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

    def test_word_report_page(self, client, mock_db_connection):
        """Тест страницы Word отчета"""
        # Мокаем данные из БД
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value

        # Настраиваем возвращаемые значения для разных запросов
        mock_cursor.fetchall.side_effect = [
            [{"full_name": "Иванов И.И.", "direction": "Футбол", "work_days": "Пн,Ср,Пт"}],  # trainers
            [{"full_name": "Петров П.П.", "position": "Администратор", "schedule": "9:00-18:00"}],  # staff
            ["Футбол", "Баскетбол"],  # workout_types
            ["Администратор", "Тренер"]  # positions
        ]

        response = client.get("/word-report")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

    def test_pdf_access_cards_page(self, client, mock_db_connection):
        """Тест страницы PDF карт доступа"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {"staff_id": 1, "full_name": "Иванов И.И.", "position": "Тренер", "schedule": "9:00-18:00"}
        ]

        response = client.get("/pdf-access-cards")
        assert response.status_code == 200

    def test_excel_trainers_report_page(self, client, mock_db_connection):
        """Тест страницы Excel отчета"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {
                "full_name": "Иванов И.И.",
                "direction": "Футбол",
                "work_days": "Пн,Ср,Пт",
                "days_count": 3,
                "estimated_lessons": 12,
                "estimated_clients": 120
            }
        ]

        response = client.get("/excel-trainers-report")
        assert response.status_code == 200


# Тесты для API endpoints
class TestAPIEndpoints:

    def test_login_success(self, client, mock_db_connection):
        """Тест успешного входа"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.return_value = {
            "user_id": 1,
            "login": "test",
            "full_name": "Test User"
        }

        response = client.post("/api/login", json={
            "login": "test",
            "password": "password"
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        assert "user" in data

    def test_login_failure(self, client, mock_db_connection):
        """Тест неудачного входа"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.return_value = None

        response = client.post("/api/login", json={
            "login": "wrong",
            "password": "wrong"
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == False

    def test_create_user_success(self, client, mock_db_connection):
        """Тест создания пользователя"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.side_effect = [
            None,  # Проверка существования пользователя
            {"user_id": 1, "full_name": "New User", "login": "newuser"}  # Создание пользователя
        ]

        response = client.post("/api/users", json={
            "full_name": "New User",
            "login": "newuser",
            "password": "password123"
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True
        assert "user" in data

    def test_create_user_duplicate(self, client, mock_db_connection):
        """Тест создания дублирующегося пользователя"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.return_value = {"user_id": 1}  # Пользователь уже существует

        response = client.post("/api/users", json={
            "full_name": "New User",
            "login": "existing",
            "password": "password123"
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == False
        assert "уже существует" in data["message"]

    def test_create_position(self, client, mock_db_connection):
        """Тест создания должности"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.side_effect = [
            None,  # Проверка существования
            {"position_id": 1, "position_name": "New Position"}  # Создание
        ]

        response = client.post("/api/positions", json={
            "position_name": "New Position"
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True

    def test_create_workout_type(self, client, mock_db_connection):
        """Тест создания типа тренировки"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.side_effect = [
            None,  # Проверка существования
            {"workout_type_id": 1, "workout_type_name": "New Workout"}  # Создание
        ]

        response = client.post("/api/workout-types", json={
            "workout_type_name": "New Workout"
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True

    def test_get_trainers(self, client, mock_db_connection):
        """Тест получения списка тренеров"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {
                "trainer_id": 1,
                "user_id": 1,
                "full_name": "Иванов И.И.",
                "workout_type_id": 1,
                "direction": "Футбол",
                "work_days": "Пн,Ср,Пт"
            }
        ]

        response = client.get("/api/trainers")
        assert response.status_code == 200
        data = response.json()
        assert len(data) > 0

    def test_get_staff(self, client, mock_db_connection):
        """Тест получения списка сотрудников"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {
                "staff_id": 1,
                "user_id": 1,
                "full_name": "Петров П.П.",
                "position_id": 1,
                "position": "Администратор",
                "schedule": "9:00-18:00"
            }
        ]

        response = client.get("/api/staff")
        assert response.status_code == 200
        data = response.json()
        assert len(data) > 0

    def test_add_trainer(self, client, mock_db_connection):
        """Тест добавления тренера"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.return_value = {"trainer_id": 1}

        response = client.post("/api/trainers", json={
            "user_id": 1,
            "workout_type_id": 1,
            "work_days": ["Пн", "Ср", "Пт"]
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True

    def test_update_trainer(self, client, mock_db_connection):
        """Тест обновления тренера"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value

        response = client.put("/api/trainers/1", json={
            "user_id": 1,
            "workout_type_id": 1,
            "work_days": ["Пн", "Ср", "Пт"]
        })

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True

    def test_delete_trainer(self, client, mock_db_connection):
        """Тест удаления тренера"""
        response = client.delete("/api/trainers/1")

        assert response.status_code == 200
        data = response.json()
        assert data["success"] == True

    def test_get_users(self, client, mock_db_connection):
        """Тест получения списка пользователей"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {"user_id": 1, "full_name": "User 1", "login": "user1"}
        ]

        response = client.get("/api/users")
        assert response.status_code == 200

    def test_get_workout_types(self, client, mock_db_connection):
        """Тест получения типов тренировок"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {"workout_type_id": 1, "workout_type_name": "Футбол"}
        ]

        response = client.get("/api/workout-types")
        assert response.status_code == 200

    def test_get_positions(self, client, mock_db_connection):
        """Тест получения должностей"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {"position_id": 1, "position_name": "Тренер"}
        ]

        response = client.get("/api/positions")
        assert response.status_code == 200


# Тесты для генерации отчетов
class TestReportGeneration:

    @patch('main.tempfile.NamedTemporaryFile')
    def test_generate_word(self, mock_tempfile, client, mock_db_connection):
        """Тест генерации Word документа"""
        # Настраиваем моки для данных из БД
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value

        # Настраиваем несколько возвращаемых значений для разных fetchall
        mock_cursor.fetchall.side_effect = [
            [{"full_name": "Иванов И.И.", "direction": "Футбол", "work_days": "Пн,Ср,Пт"}],  # trainers
            [{"full_name": "Петров П.П.", "position": "Администратор", "schedule": "9:00-18:00"}],  # staff
            ["Футбол", "Баскетбол"],  # workout_types
            ["Администратор", "Тренер"]  # positions
        ]

        # Мокаем временный файл
        mock_file = MagicMock()
        mock_file.name = "test.docx"
        mock_tempfile.return_value.__enter__.return_value = mock_file

        response = client.get("/api/generate-word")
        assert response.status_code == 200
        assert "application/vnd.openxmlformats-officedocument" in response.headers["content-type"]

    @patch('main.tempfile.NamedTemporaryFile')
    def test_generate_excel_trainers(self, mock_tempfile, client, mock_db_connection):
        """Тест генерации Excel отчета по тренерам"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchall.return_value = [
            {
                "trainer_name": "Иванов И.И.",
                "direction": "Футбол",
                "work_days": "Пн,Ср,Пт",
                "days_count": 3,
                "estimated_lessons": 12,
                "estimated_clients": 120
            }
        ]

        mock_file = MagicMock()
        mock_file.name = "test.xlsx"
        mock_tempfile.return_value.__enter__.return_value = mock_file

        response = client.get("/api/generate-excel-trainers")
        assert response.status_code == 200
        assert "application/vnd.openxmlformats-officedocument" in response.headers["content-type"]

    @patch('main.tempfile.NamedTemporaryFile')
    def test_generate_pdf_card(self, mock_tempfile, client, mock_db_connection):
        """Тест генерации PDF карты доступа"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.return_value = {
            "full_name": "Иванов И.И.",
            "position": "Тренер",
            "schedule": "9:00-18:00"
        }

        mock_file = MagicMock()
        mock_file.name = "test.pdf"
        mock_tempfile.return_value.__enter__.return_value = mock_file

        response = client.get("/api/generate-pdf-card/1")
        assert response.status_code == 200
        assert "application/pdf" in response.headers["content-type"]

    def test_generate_pdf_card_not_found(self, client, mock_db_connection):
        """Тест генерации PDF для несуществующего сотрудника"""
        mock_cursor = mock_db_connection.return_value.cursor.return_value.__enter__.return_value
        mock_cursor.fetchone.return_value = None

        response = client.get("/api/generate-pdf-card/999")
        assert response.status_code == 200
        data = response.json()
        assert data["error"] == "Сотрудник не найден"


# Тесты для вспомогательных функций
class TestHelperFunctions:

    def test_get_duties_description(self):
        """Тест функции получения обязанностей"""
        from main import get_duties_description

        # Импортируем функцию напрямую для тестирования

        # Тест для администратора
        duties = get_duties_description("Администратор")
        assert len(duties) > 0
        assert "Встреча посетителей" in duties

        # Тест для тренера
        duties = get_duties_description("Тренер")
        assert "Проведение тренировок" in duties

        # Тест для неизвестной должности
        duties = get_duties_description("Неизвестная должность")
        assert len(duties) == 3  # Общие обязанности
        assert "Выполнение должностных обязанностей" in duties


# Тесты для обработки ошибок
class TestErrorHandling:

    def test_database_connection_error(self, client):
        """Тест ошибки подключения к БД"""
        with patch('database.get_db_connection') as mock_conn:
            mock_conn.side_effect = Exception("Database connection error")

            response = client.get("/api/trainers")
            assert response.status_code == 500

    def test_invalid_json(self, client):
        """Тест невалидного JSON"""
        response = client.post("/api/login", data="invalid json")
        assert response.status_code == 400  # FastAPI вернет 400 для невалидного JSON

    def test_missing_required_fields(self, client):
        """Тест отсутствия обязательных полей"""
        response = client.post("/api/users", json={
            "full_name": "Test User"
            # Отсутствуют login и password
        })

        # FastAPI автоматически проверяет обязательные поля
        assert response.status_code == 422  # Unprocessable Entity


# Тесты для конфигурации
def test_cors_middleware(client):
    """Тест CORS middleware"""
    response = client.options("/", headers={
        "Origin": "http://localhost",
        "Access-Control-Request-Method": "GET"
    })
    assert "access-control-allow-origin" in response.headers
    assert response.headers["access-control-allow-origin"] == "*"


def test_database_config():
    """Тест конфигурации БД"""
    from database import DB_CONFIG

    assert "dbname" in DB_CONFIG
    assert "user" in DB_CONFIG
    assert "password" in DB_CONFIG
    assert "host" in DB_CONFIG
    assert "port" in DB_CONFIG


# Тест для контекстного менеджера БД
def test_get_db_context_manager():
    """Тест контекстного менеджера для работы с БД"""
    from main import get_db
    from database import get_db_connection

    with patch('database.get_db_connection') as mock_conn:
        mock_connection = MagicMock()
        mock_conn.return_value = mock_connection

        with get_db() as conn:
            assert conn == mock_connection

        mock_connection.close.assert_called_once()