import pytest
import sys

if __name__ == "__main__":
    # Запускаем тесты с отчетом о покрытии
    args = [
        "test_main.py",
        "-v",  # Подробный вывод
        "--cov=.",  # Покрытие всего проекта
        "--cov-report=term",  # Отчет в терминале
        "--cov-report=html",  # HTML отчет
        "--cov-report=xml",   # XML отчет
    ]
    sys.exit(pytest.main(args))