CREATE TABLE trainer_schedules (
    schedule_id SERIAL PRIMARY KEY,
    trainer_id INTEGER NOT NULL REFERENCES trainers(trainer_id),
    day_of_week VARCHAR(2) NOT NULL
);