from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
import database
from contextlib import contextmanager
import os
import uvicorn
from datetime import datetime
from docx import Document
from docx.shared import Inches
import tempfile
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A6
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import io
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill

app = FastAPI(title="Спортикус")

# Добавляем CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Настройка шаблонов
templates = Jinja2Templates(directory="templates")


# Вспомогательная функция для работы с БД
@contextmanager
def get_db():
    conn = database.get_db_connection()
    try:
        yield conn
    finally:
        conn.close()


# Главная страница
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# Страница для генерации Word документа
@app.get("/word-report", response_class=HTMLResponse)
async def word_report(request: Request):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Получаем данные тренеров
                cur.execute("""
                    SELECT 
                        u.full_name,
                        wt.workout_type_name as direction,
                        STRING_AGG(ts.day_of_week, ',' ORDER BY 
                            CASE ts.day_of_week
                                WHEN 'Пн' THEN 1 WHEN 'Вт' THEN 2 WHEN 'Ср' THEN 3
                                WHEN 'Чт' THEN 4 WHEN 'Пт' THEN 5 WHEN 'Сб' THEN 6
                                WHEN 'Вс' THEN 7
                            END) as work_days
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    JOIN workout_types wt ON t.workout_type_id = wt.workout_type_id
                    JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                    GROUP BY u.full_name, wt.workout_type_name
                    ORDER BY u.full_name
                """)
                trainers = [dict(row) for row in cur.fetchall()]

                # Получаем данные сотрудников
                cur.execute("""
                    SELECT 
                        u.full_name,
                        p.position_name as position,
                        s.work_schedule as schedule
                    FROM staff s
                    JOIN users u ON s.user_id = u.user_id
                    JOIN positions p ON s.position_id = p.position_id
                    ORDER BY u.full_name
                """)
                staff = [dict(row) for row in cur.fetchall()]

                # Получаем типы тренировок
                cur.execute("SELECT workout_type_name FROM workout_types ORDER BY workout_type_name")
                workout_types = [row['workout_type_name'] for row in cur.fetchall()]

                # Получаем должности
                cur.execute("SELECT position_name FROM positions ORDER BY position_name")
                positions = [row['position_name'] for row in cur.fetchall()]

        current_date = datetime.now().strftime("%d.%m.%Y")

        return templates.TemplateResponse("word_report.html", {
            "request": request,
            "trainers": trainers,
            "staff": staff,
            "workout_types": workout_types,
            "positions": positions,
            "current_date": current_date
        })

    except Exception as e:
        return JSONResponse({"error": f"Ошибка генерации отчета: {str(e)}"}, status_code=500)


# Страница для генерации PDF карт доступа
@app.get("/pdf-access-cards", response_class=HTMLResponse)
async def pdf_access_cards(request: Request):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Получаем данные сотрудников
                cur.execute("""
                    SELECT 
                        s.staff_id,
                        u.full_name,
                        p.position_name as position,
                        s.work_schedule as schedule
                    FROM staff s
                    JOIN users u ON s.user_id = u.user_id
                    JOIN positions p ON s.position_id = p.position_id
                    ORDER BY u.full_name
                """)
                staff = [dict(row) for row in cur.fetchall()]

        return templates.TemplateResponse("pdf_access_cards.html", {
            "request": request,
            "staff": staff
        })

    except Exception as e:
        return JSONResponse({"error": f"Ошибка загрузки данных: {str(e)}"}, status_code=500)


# Страница для генерации Excel отчета по тренерам
@app.get("/excel-trainers-report", response_class=HTMLResponse)
async def excel_trainers_report(request: Request):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Получаем расширенные данные тренеров
                cur.execute("""
                    SELECT 
                        u.full_name,
                        wt.workout_type_name as direction,
                        STRING_AGG(ts.day_of_week, ',' ORDER BY 
                            CASE ts.day_of_week
                                WHEN 'Пн' THEN 1 WHEN 'Вт' THEN 2 WHEN 'Ср' THEN 3
                                WHEN 'Чт' THEN 4 WHEN 'Пт' THEN 5 WHEN 'Сб' THEN 6
                                WHEN 'Вс' THEN 7
                            END) as work_days,
                        COUNT(DISTINCT ts.day_of_week) as days_count,
                        (COUNT(DISTINCT ts.day_of_week) * 4) as estimated_lessons,
                        (COUNT(DISTINCT ts.day_of_week) * 4 * 10) as estimated_clients
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    JOIN workout_types wt ON t.workout_type_id = wt.workout_type_id
                    JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                    GROUP BY u.full_name, wt.workout_type_name
                    ORDER BY u.full_name
                """)
                trainers = [dict(row) for row in cur.fetchall()]

        return templates.TemplateResponse("excel_trainers_report.html", {
            "request": request,
            "trainers": trainers
        })

    except Exception as e:
        return JSONResponse({"error": f"Ошибка загрузки данных: {str(e)}"}, status_code=500)


# API для генерации и скачивания Word документа
@app.get("/api/generate-word")
async def generate_word():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Получаем данные тренеров
                cur.execute("""
                    SELECT 
                        u.full_name,
                        wt.workout_type_name as direction,
                        STRING_AGG(ts.day_of_week, ',' ORDER BY 
                            CASE ts.day_of_week
                                WHEN 'Пн' THEN 1 WHEN 'Вт' THEN 2 WHEN 'Ср' THEN 3
                                WHEN 'Чт' THEN 4 WHEN 'Пт' THEN 5 WHEN 'Сб' THEN 6
                                WHEN 'Вс' THEN 7
                            END) as work_days
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    JOIN workout_types wt ON t.workout_type_id = wt.workout_type_id
                    JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                    GROUP BY u.full_name, wt.workout_type_name
                    ORDER BY u.full_name
                """)
                trainers = [dict(row) for row in cur.fetchall()]

                # Получаем данные сотрудников
                cur.execute("""
                    SELECT 
                        u.full_name,
                        p.position_name as position,
                        s.work_schedule as schedule
                    FROM staff s
                    JOIN users u ON s.user_id = u.user_id
                    JOIN positions p ON s.position_id = p.position_id
                    ORDER BY u.full_name
                """)
                staff = [dict(row) for row in cur.fetchall()]

                # Получаем типы тренировок
                cur.execute("SELECT workout_type_name FROM workout_types ORDER BY workout_type_name")
                workout_types = [row['workout_type_name'] for row in cur.fetchall()]

                # Получаем должности
                cur.execute("SELECT position_name FROM positions ORDER BY position_name")
                positions = [row['position_name'] for row in cur.fetchall()]

        # Создаем Word документ
        doc = Document()

        # Заголовок
        title = doc.add_heading('Фитнес-клуб', 0)
        title.alignment = 1

        sporticus_title = doc.add_heading('СПОРТИКУС', 1)
        sporticus_title.alignment = 1

        doc.add_paragraph('Система управления спортивными секциями').alignment = 1
        doc.add_paragraph()

        # Секция тренеров
        doc.add_heading('1. Список тренеров спортивных секций', level=1)
        if trainers:
            table = doc.add_table(rows=1, cols=3)
            table.style = 'Table Grid'

            # Заголовки таблицы
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = 'Ф.И.О. тренера'
            hdr_cells[1].text = 'Направление подготовки'
            hdr_cells[2].text = 'Дни проведения занятий'

            # Данные тренеров
            for trainer in trainers:
                row_cells = table.add_row().cells
                row_cells[0].text = trainer['full_name']
                row_cells[1].text = trainer['direction']
                row_cells[2].text = trainer['work_days'].replace(',', ', ')
        else:
            doc.add_paragraph('Данные о тренерах отсутствуют').italic = True

        doc.add_paragraph()

        # Секция персонала
        doc.add_heading('2. Список административного персонала', level=1)
        if staff:
            table = doc.add_table(rows=1, cols=3)
            table.style = 'Table Grid'

            # Заголовки таблицы
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = 'Ф.И.О. сотрудника'
            hdr_cells[1].text = 'Должность'
            hdr_cells[2].text = 'График работы'

            # Данные сотрудников
            for employee in staff:
                row_cells = table.add_row().cells
                row_cells[0].text = employee['full_name']
                row_cells[1].text = employee['position']
                row_cells[2].text = employee['schedule']
        else:
            doc.add_paragraph('Данные о персонале отсутствуют').italic = True

        doc.add_paragraph()

        # Секция направлений подготовки
        doc.add_heading('3. Перечень спортивных направлений', level=1)
        if workout_types:
            table = doc.add_table(rows=1, cols=2)
            table.style = 'Table Grid'

            # Заголовки таблицы
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = '№'
            hdr_cells[1].text = 'Наименование направления подготовки'

            # Данные направлений
            for i, workout_type in enumerate(workout_types, 1):
                row_cells = table.add_row().cells
                row_cells[0].text = str(i)
                row_cells[1].text = workout_type
        else:
            doc.add_paragraph('Данные о направлениях подготовки отсутствуют').italic = True

        doc.add_paragraph()

        # Секция должностей
        doc.add_heading('4. Штатное расписание', level=1)
        if positions:
            table = doc.add_table(rows=1, cols=2)
            table.style = 'Table Grid'

            # Заголовки таблицы
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = '№'
            hdr_cells[1].text = 'Наименование должности'

            # Данные должностей
            for i, position in enumerate(positions, 1):
                row_cells = table.add_row().cells
                row_cells[0].text = str(i)
                row_cells[1].text = position
        else:
            doc.add_paragraph('Данные о должностях отсутствуют').italic = True

        # Футер
        doc.add_paragraph()
        current_date = datetime.now().strftime("%d.%m.%Y")
        footer = doc.add_paragraph(f'Отчет сгенерирован: {current_date}\nСистема "Спортикус"')
        footer.alignment = 2

        # Сохраняем во временный файл
        with tempfile.NamedTemporaryFile(delete=False, suffix='.docx') as tmp_file:
            doc.save(tmp_file.name)
            tmp_file_path = tmp_file.name

        # Возвращаем файл как ответ
        return FileResponse(
            tmp_file_path,
            media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            filename=f'отчет_спортикус_{current_date}.docx'
        )

    except Exception as e:
        return JSONResponse({"error": f"Ошибка генерации Word документа: {str(e)}"}, status_code=500)


# API для генерации Excel отчета по тренерам
@app.get("/api/generate-excel-trainers")
async def generate_excel_trainers():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Получаем расширенные данные тренеров
                cur.execute("""
                    SELECT 
                        u.full_name as trainer_name,
                        wt.workout_type_name as direction,
                        STRING_AGG(ts.day_of_week, ',' ORDER BY 
                            CASE ts.day_of_week
                                WHEN 'Пн' THEN 1 WHEN 'Вт' THEN 2 WHEN 'Ср' THEN 3
                                WHEN 'Чт' THEN 4 WHEN 'Пт' THEN 5 WHEN 'Сб' THEN 6
                                WHEN 'Вс' THEN 7
                            END) as work_days,
                        COUNT(DISTINCT ts.day_of_week) as days_count,
                        (COUNT(DISTINCT ts.day_of_week) * 4) as estimated_lessons,
                        (COUNT(DISTINCT ts.day_of_week) * 4 * 10) as estimated_clients
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    JOIN workout_types wt ON t.workout_type_id = wt.workout_type_id
                    JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                    GROUP BY u.full_name, wt.workout_type_name
                    ORDER BY u.full_name
                """)
                trainers = [dict(row) for row in cur.fetchall()]

        # Создаем Excel workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Отчет по тренерам"

        # Заголовок отчета
        ws.merge_cells('A1:F1')
        ws['A1'] = 'ОТЧЕТ ПО ТРЕНЕРАМ - СПОРТИКУС'
        ws['A1'].font = Font(size=16, bold=True)
        ws['A1'].alignment = Alignment(horizontal='center')

        ws.merge_cells('A2:F2')
        ws['A2'] = 'Статистика тренерской деятельности'
        ws['A2'].font = Font(size=12, italic=True)
        ws['A2'].alignment = Alignment(horizontal='center')

        # Заголовки столбцов
        headers = [
            'ФИО тренера',
            'Направление',
            'Дни работы',
            'Кол-во рабочих дней',
            'Кол-во занятий в неделю',
            'Ориентировочное кол-во клиентов'
        ]

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=4, column=col, value=header)
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")
            cell.alignment = Alignment(horizontal='center')

        # Данные тренеров
        for row, trainer in enumerate(trainers, 5):
            ws.cell(row=row, column=1, value=trainer['trainer_name'])
            ws.cell(row=row, column=2, value=trainer['direction'])
            ws.cell(row=row, column=3, value=trainer['work_days'].replace(',', ', '))
            ws.cell(row=row, column=4, value=trainer['days_count'])
            ws.cell(row=row, column=5, value=trainer['estimated_lessons'])
            ws.cell(row=row, column=6, value=trainer['estimated_clients'])

        # Настройка ширины столбцов
        column_widths = [30, 25, 20, 18, 22, 25]
        for col, width in enumerate(column_widths, 1):
            ws.column_dimensions[chr(64 + col)].width = width

        # Добавляем итоги
        total_row = len(trainers) + 6
        ws.cell(row=total_row, column=1, value="ИТОГО:").font = Font(bold=True)
        ws.cell(row=total_row, column=4, value=f"=SUM(D5:D{total_row - 1})").font = Font(bold=True)
        ws.cell(row=total_row, column=5, value=f"=SUM(E5:E{total_row - 1})").font = Font(bold=True)
        ws.cell(row=total_row, column=6, value=f"=SUM(F5:F{total_row - 1})").font = Font(bold=True)

        # Добавляем дату генерации
        current_date = datetime.now().strftime("%d.%m.%Y %H:%M")
        ws.cell(row=total_row + 2, column=1, value=f"Отчет сгенерирован: {current_date}").font = Font(italic=True)

        # Сохраняем во временный файл
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
            wb.save(tmp_file.name)
            tmp_file_path = tmp_file.name

        # Возвращаем файл как ответ
        current_date_file = datetime.now().strftime("%d.%m.%Y")
        return FileResponse(
            tmp_file_path,
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            filename=f'отчет_тренеры_{current_date_file}.xlsx'
        )

    except Exception as e:
        return JSONResponse({"error": f"Ошибка генерации Excel отчета: {str(e)}"}, status_code=500)


# API для генерации PDF карты доступа
@app.get("/api/generate-pdf-card/{staff_id}")
async def generate_pdf_card(staff_id: int):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Получаем данные сотрудника
                cur.execute("""
                    SELECT 
                        u.full_name,
                        p.position_name as position,
                        s.work_schedule as schedule
                    FROM staff s
                    JOIN users u ON s.user_id = u.user_id
                    JOIN positions p ON s.position_id = p.position_id
                    WHERE s.staff_id = %s
                """, (staff_id,))
                employee = cur.fetchone()

                if not employee:
                    return JSONResponse({"error": "Сотрудник не найден"}, status_code=404)

        # Создаем PDF документ
        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=A6)
        width, height = A6

        # Устанавливаем шрифты
        try:
            pdfmetrics.registerFont(TTFont('Arial', 'arial.ttf'))
            pdfmetrics.registerFont(TTFont('Arial-Bold', 'arialbd.ttf'))
            font_normal = 'Arial'
            font_bold = 'Arial-Bold'
        except:
            # Если шрифты не найдены, используем стандартные
            font_normal = 'Helvetica'
            font_bold = 'Helvetica-Bold'

        # Фон карты
        c.setFillColorRGB(0.9, 0.9, 0.9)  # Светло-серый фон
        c.rect(0, 0, width, height, fill=1)

        # Заголовок карты
        c.setFillColorRGB(0.2, 0.4, 0.6)  # Синий цвет
        c.rect(5 * mm, height - 25 * mm, width - 10 * mm, 20 * mm, fill=1)

        c.setFillColorRGB(1, 1, 1)  # Белый текст
        c.setFont(font_bold, 14)
        c.drawCentredString(width / 2, height - 15 * mm, "КАРТА ДОСТУПА")
        c.setFont(font_bold, 10)
        c.drawCentredString(width / 2, height - 20 * mm, "Спортикус")

        # Фото сотрудника (заглушка)
        c.setFillColorRGB(0.8, 0.8, 0.8)
        c.rect(10 * mm, height - 70 * mm, 35 * mm, 40 * mm, fill=1)
        c.setFillColorRGB(0.5, 0.5, 0.5)
        c.setFont(font_normal, 8)
        c.drawCentredString(27.5 * mm, height - 85 * mm, "ФОТО")

        # Информация о сотруднике
        c.setFillColorRGB(0, 0, 0)
        c.setFont(font_bold, 12)
        c.drawString(50 * mm, height - 45 * mm, "СОТРУДНИК:")
        c.setFont(font_normal, 10)
        c.drawString(50 * mm, height - 52 * mm, employee['full_name'])

        c.setFont(font_bold, 12)
        c.drawString(50 * mm, height - 62 * mm, "ДОЛЖНОСТЬ:")
        c.setFont(font_normal, 10)
        c.drawString(50 * mm, height - 69 * mm, employee['position'])

        c.setFont(font_bold, 12)
        c.drawString(10 * mm, height - 95 * mm, "ГРАФИК РАБОТЫ:")
        c.setFont(font_normal, 10)
        c.drawString(10 * mm, height - 102 * mm, employee['schedule'])

        # Обязанности (краткое описание)
        c.setFont(font_bold, 12)
        c.drawString(10 * mm, height - 115 * mm, "ОБЯЗАННОСТИ:")
        c.setFont(font_normal, 8)

        # Описание обязанностей в зависимости от должности
        duties = get_duties_description(employee['position'])
        y_position = height - 122 * mm
        for duty in duties:
            if y_position > 20 * mm:  # Проверяем, чтобы не выйти за границы
                c.drawString(15 * mm, y_position, "• " + duty)
                y_position -= 6 * mm

        # QR-код зона (заглушка)
        c.setFillColorRGB(0.9, 0.9, 0.9)
        c.rect(width - 30 * mm, 10 * mm, 25 * mm, 25 * mm, fill=1)
        c.setFillColorRGB(0.5, 0.5, 0.5)
        c.setFont(font_normal, 6)
        c.drawCentredString(width - 17.5 * mm, 20 * mm, "QR-CODE")

        # Дата выдачи
        current_date = datetime.now().strftime("%d.%m.%Y")
        c.setFont(font_normal, 8)
        c.drawString(10 * mm, 10 * mm, f"Выдана: {current_date}")

        c.save()

        buffer.seek(0)

        # Сохраняем во временный файл
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp_file:
            tmp_file.write(buffer.getvalue())
            tmp_file_path = tmp_file.name

        # Возвращаем файл как ответ
        return FileResponse(
            tmp_file_path,
            media_type='application/pdf',
            filename=f'карта_доступа_{employee["full_name"].replace(" ", "_")}.pdf'
        )

    except Exception as e:
        return JSONResponse({"error": f"Ошибка генерации PDF карты: {str(e)}"}, status_code=500)


def get_duties_description(position):
    """Возвращает описание обязанностей в зависимости от должности"""
    duties_map = {
        "Администратор": [
            "Встреча посетителей",
            "Регистрация клиентов",
            "Контроль доступа",
            "Прием платежей"
        ],
        "Тренер": [
            "Проведение тренировок",
            "Составление программ",
            "Контроль техники",
            "Консультации"
        ],
        "Менеджер": [
            "Управление персоналом",
            "Планирование расписания",
            "Контроль качества",
            "Отчетность"
        ],
        "Уборщик": [
            "Поддержание чистоты",
            "Уборка помещений",
            "Санобработка",
            "Вынос мусора"
        ],
        "Охранник": [
            "Контроль доступа",
            "Обход территории",
            "Обеспечение порядка",
            "Чрезвычайные ситуации"
        ]
    }

    # Ищем подходящие обязанности
    for key, duties in duties_map.items():
        if key.lower() in position.lower():
            return duties

    # Если должность не найдена, возвращаем общие обязанности
    return [
        "Выполнение должностных обязанностей",
        "Соблюдение правил внутреннего распорядка",
        "Поддержание рабочей дисциплины"
    ]


# API для входа в систему
@app.post("/api/login")
async def login(request: Request):
    try:
        data = await request.json()
        login = data.get("login")
        password = data.get("password")

        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM users WHERE login = %s AND password_hash = %s", (login, password))
                user = cur.fetchone()

        if user:
            return JSONResponse({"success": True, "message": "Успешный вход", "user": dict(user)})
        else:
            return JSONResponse({"success": False, "message": "Неверный логин или пароль"})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка сервера: {str(e)}"})


# API для создания нового пользователя
@app.post("/api/users")
async def create_user(request: Request):
    try:
        data = await request.json()
        full_name = data.get("full_name")
        login = data.get("login")
        password = data.get("password")

        with get_db() as conn:
            with conn.cursor() as cur:
                # Проверяем, нет ли уже пользователя с таким логином
                cur.execute("SELECT * FROM users WHERE login = %s", (login,))
                existing_user = cur.fetchone()

                if existing_user:
                    return JSONResponse({"success": False, "message": "Пользователь с таким логином уже существует"})

                # Создаем нового пользователя
                cur.execute("""
                    INSERT INTO users (full_name, login, password_hash) 
                    VALUES (%s, %s, %s) RETURNING user_id, full_name, login
                """, (full_name, login, password))

                new_user = cur.fetchone()
                conn.commit()

        return JSONResponse({"success": True, "message": "Пользователь успешно создан", "user": dict(new_user)})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для создания новой должности
@app.post("/api/positions")
async def create_position(request: Request):
    try:
        data = await request.json()
        position_name = data.get("position_name")

        with get_db() as conn:
            with conn.cursor() as cur:
                # Проверяем, нет ли уже такой должности
                cur.execute("SELECT * FROM positions WHERE position_name = %s", (position_name,))
                existing_position = cur.fetchone()

                if existing_position:
                    return JSONResponse({"success": False, "message": "Должность с таким названием уже существует"})

                # Создаем новую должность
                cur.execute("""
                    INSERT INTO positions (position_name) 
                    VALUES (%s) RETURNING position_id, position_name
                """, (position_name,))

                new_position = cur.fetchone()
                conn.commit()

        return JSONResponse({"success": True, "message": "Должность успешно создана", "position": dict(new_position)})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для создания нового типа тренировки
@app.post("/api/workout-types")
async def create_workout_type(request: Request):
    try:
        data = await request.json()
        workout_type_name = data.get("workout_type_name")

        with get_db() as conn:
            with conn.cursor() as cur:
                # Проверяем, нет ли уже такого типа тренировки
                cur.execute("SELECT * FROM workout_types WHERE workout_type_name = %s", (workout_type_name,))
                existing_type = cur.fetchone()

                if existing_type:
                    return JSONResponse(
                        {"success": False, "message": "Тип тренировки с таким названием уже существует"})

                # Создаем новый тип тренировки
                cur.execute("""
                    INSERT INTO workout_types (workout_type_name) 
                    VALUES (%s) RETURNING workout_type_id, workout_type_name
                """, (workout_type_name,))

                new_type = cur.fetchone()
                conn.commit()

        return JSONResponse(
            {"success": True, "message": "Тип тренировки успешно создан", "workout_type": dict(new_type)})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для получения списка тренеров
@app.get("/api/trainers")
async def get_trainers():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        t.trainer_id,
                        u.user_id,
                        u.full_name,
                        wt.workout_type_id,
                        wt.workout_type_name as direction,
                        STRING_AGG(ts.day_of_week, ',' ORDER BY 
                            CASE ts.day_of_week
                                WHEN 'Пн' THEN 1 WHEN 'Вт' THEN 2 WHEN 'Ср' THEN 3
                                WHEN 'Чт' THEN 4 WHEN 'Пт' THEN 5 WHEN 'Сб' THEN 6
                                WHEN 'Вс' THEN 7
                            END) as work_days
                    FROM trainers t
                    JOIN users u ON t.user_id = u.user_id
                    JOIN workout_types wt ON t.workout_type_id = wt.workout_type_id
                    JOIN trainer_schedules ts ON t.trainer_id = ts.trainer_id
                    GROUP BY t.trainer_id, u.user_id, u.full_name, wt.workout_type_id, wt.workout_type_name
                    ORDER BY u.full_name
                """)
                trainers = [dict(row) for row in cur.fetchall()]

        return trainers
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# API для получения списка сотрудников
@app.get("/api/staff")
async def get_staff():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        s.staff_id,
                        u.user_id,
                        u.full_name,
                        p.position_id,
                        p.position_name as position,
                        s.work_schedule as schedule
                    FROM staff s
                    JOIN users u ON s.user_id = u.user_id
                    JOIN positions p ON s.position_id = p.position_id
                    ORDER BY u.full_name
                """)
                staff = [dict(row) for row in cur.fetchall()]

        return staff
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# API для добавления тренера
@app.post("/api/trainers")
async def add_trainer(request: Request):
    try:
        data = await request.json()

        with get_db() as conn:
            with conn.cursor() as cur:
                # Добавляем тренера
                cur.execute("""
                    INSERT INTO trainers (user_id, workout_type_id) 
                    VALUES (%s, %s) RETURNING trainer_id
                """, (data['user_id'], data['workout_type_id']))

                trainer_id = cur.fetchone()['trainer_id']

                # Добавляем дни работы
                for day in data['work_days']:
                    cur.execute("""
                        INSERT INTO trainer_schedules (trainer_id, day_of_week)
                        VALUES (%s, %s)
                    """, (trainer_id, day))

                conn.commit()

        return JSONResponse({"success": True, "message": "Тренер успешно добавлен"})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для обновления тренера
@app.put("/api/trainers/{trainer_id}")
async def update_trainer(trainer_id: int, request: Request):
    try:
        data = await request.json()

        with get_db() as conn:
            with conn.cursor() as cur:
                # Обновляем тренера
                cur.execute("""
                    UPDATE trainers 
                    SET user_id = %s, workout_type_id = %s 
                    WHERE trainer_id = %s
                """, (data['user_id'], data['workout_type_id'], trainer_id))

                # Удаляем старые дни работы
                cur.execute("DELETE FROM trainer_schedules WHERE trainer_id = %s", (trainer_id,))

                # Добавляем новые дни работы
                for day in data['work_days']:
                    cur.execute("""
                        INSERT INTO trainer_schedules (trainer_id, day_of_week)
                        VALUES (%s, %s)
                    """, (trainer_id, day))

                conn.commit()

        return JSONResponse({"success": True, "message": "Тренер успешно обновлен"})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для удаления тренера
@app.delete("/api/trainers/{trainer_id}")
async def delete_trainer(trainer_id: int):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Удаляем расписание тренера
                cur.execute("DELETE FROM trainer_schedules WHERE trainer_id = %s", (trainer_id,))
                # Удаляем тренера
                cur.execute("DELETE FROM trainers WHERE trainer_id = %s", (trainer_id,))
                conn.commit()

        return JSONResponse({"success": True, "message": "Тренер успешно удален"})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для добавления сотрудника
@app.post("/api/staff")
async def add_staff(request: Request):
    try:
        data = await request.json()

        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO staff (user_id, position_id, work_schedule) 
                    VALUES (%s, %s, %s) RETURNING staff_id
                """, (data['user_id'], data['position_id'], data['schedule']))

                conn.commit()

        return JSONResponse({"success": True, "message": "Сотрудник успешно добавлен"})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для обновления сотрудника
@app.put("/api/staff/{staff_id}")
async def update_staff(staff_id: int, request: Request):
    try:
        data = await request.json()

        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    UPDATE staff 
                    SET user_id = %s, position_id = %s, work_schedule = %s 
                    WHERE staff_id = %s
                """, (data['user_id'], data['position_id'], data['schedule'], staff_id))

                conn.commit()

        return JSONResponse({"success": True, "message": "Сотрудник успешно обновлен"})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для удаления сотрудника
@app.delete("/api/staff/{staff_id}")
async def delete_staff(staff_id: int):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM staff WHERE staff_id = %s", (staff_id,))
                conn.commit()

        return JSONResponse({"success": True, "message": "Сотрудник успешно удален"})
    except Exception as e:
        return JSONResponse({"success": False, "message": f"Ошибка: {str(e)}"})


# API для получения пользователей
@app.get("/api/users")
async def get_users():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT user_id, full_name, login FROM users ORDER BY full_name")
                users = [dict(row) for row in cur.fetchall()]

        return users
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# API для получения типов тренировок
@app.get("/api/workout-types")
async def get_workout_types():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT workout_type_id, workout_type_name FROM workout_types ORDER BY workout_type_name")
                workout_types = [dict(row) for row in cur.fetchall()]

        return workout_types
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# API для получения должностей
@app.get("/api/positions")
async def get_positions():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT position_id, position_name FROM positions ORDER BY position_name")
                positions = [dict(row) for row in cur.fetchall()]

        return positions
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)